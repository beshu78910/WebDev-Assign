class Node {
    constructor(val) {
    this.val = val;
    this.next = null;
    this.prev = null;
    }
}
 
class doublyLinkedList{
    constructor() {
        this.head = null;
        this.tail = null;
    }

}
    