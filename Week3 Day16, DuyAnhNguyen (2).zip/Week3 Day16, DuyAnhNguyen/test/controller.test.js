const UserController = require("../controller/UserController");
const sinon = require('sinon');
const User = require("../model/User");
// require("../db");
const app = require("../app")
const bcrypt = require("bcrypt");
const { expect } = require("chai");
const request = require("supertest");

  
describe("User ControllerRoutes", function () {
    describe("Post /register", function () {

it("should add a user if there is no user with the same email in the DB", async function () {
    await User.deleteOne();
    const res = await request(app).post("/register").send({
        name: 'testname',
        email: 'test1@gmail.com',
        password: 'tester'
    })
    expect(res.status).to.equal(200);
  
});
it('should throw an error there is user with that email', async function () {
            const res = await request(app).post("/register").send({
                name: 'testname',
                email: 'test1@gmail.com',
                password: 'tester'
            })
            expect(res.status).to.equal(401);
            
    })       
    })
 describe("Post /login", function () {
        it('should not log in there is no user exist in data base', async function () {
            // await User.deleteOne();
            const res = await request(app).post('/login').send({
                email: 'test@gmail.com',
                password: 'tester'
            })
            // expect(info.password).to.not.equal(users.password);
            expect(res.status).to.equal(404);
        })

        it('should log in if there is user in the database', async function () {
            await User.deleteOne();
            const res = await request(app).post('/register').send({
                name: 'test2',
                email: 'test2@gmail.com',
                password: 'test2'
            })
            
            const users = await User.findOne({
                email: res.body.userDB.email,
                password: res.body.userDB.password
            })
            expect(users.email).to.equal(res.body.userDB.email)
            expect(users.password).to.equal(res.body.userDB.password)
            expect(res.status).to.equal(200)
        })
        
 })
    
 describe("Get /songs", function () {
    it('should display a list of liked song of current user', async function () {
        await User.deleteOne();
        const res = await request(app).post('/register').send({
            name: 'test3',
            email: 'test3@gmail.com',
            password: 'test3',
            favSong: [{
                id: "3",
                 name: "Chinisesong",
                 language: "Chinise",
                 category: "lofi"
             },
             {
               id: "4",
                 name: "Vietsong",
                 language: "Vietnamese",
                 category: "rock"
             }]
        })
        const resSong = await request(app).post('/login').send({
            email: 'test3@gmail.com',
            password: res.body.userDB.password
        })
        const resDisplay = await request(app).get('/songs')
        const users = await User.findOne({
            email: resSong.body.users.email,
        })
        expect(resSong.body.users.favSong).to.deep.equal(users.favSong);
        expect(resDisplay.status).to.equal(200);
    })
    it('should display song based on language', async function () {
        // await User.deleteOne();
        const res = await request(app).get('/songs?language=hindu')
        // expect(info.password).to.not.equal(users.password);
        expect(res.status).to.equal(200);
    })

 })
 
    describe("Get /songs/:category", function () {
        it('return list song based on category', async function () {
            
            const res = await request(app).get('/songs/rock')
            // // const req = await request(app).get('/songs/rock') 
            // // const res1 = await request(app).get('/songs/pop')
            // expect(res.body[0].category).to.equal('rock');
            expect(res.status).to.equal(200);
        })
        
    })
    describe("Get /songs/:songs_id", function () {
        it('succesfully like a song if exist', async function () {
            const res = await request(app).post('/songs/1')
            // console.log(res);
            expect(res.status).to.equal(200);
        })
        it('should not do anything if song does not exist', async function () {
            const res = await request(app).post('/songs/10')
            expect(res.status).to.equal(404);
        })
        
    })
    
    describe("Get /users/info", function () {
        it('should return error if user not found', async function () {
            const res = await request(app).post('/user/info').send({
                name: 'randomguy',
                password: 'randompassword'
                
            })
            expect(res.status).to.equal(404);
        }) 
        // it('should update info if user found', async function () {
        //     const res = await request(app).post('/user/info')
        //     expect(res.status).to.equal(200);
        // })
    })
    describe("Post /artist/:artist_name", function () {
        it('if artist does not exist display corresponding message', async function () {
            const res = await request(app).post('/artist/artist20') 
            expect(res.status).to.equal(404);
        })
        it('if artist exist add in favorite artist', async function () {
            const res = await request(app).post('/artist/artist1') 
            expect(res.status).to.equal(200);
        })
    })
})
// });
